import matplotlib as plt
import os
import csv
import threading
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from time import sleep
from PIL import ImageTk, Image

plt.use('TkAgg')

# Case-switch pre vyrabanie listu datumov zo suborov dat
mon_list = {1: 'Január', 2: 'Február', 3: 'Marec', 4: 'Apríl', 5: 'Máj', 6: 'Jún', 7: 'Júl',
            8: 'August', 9: 'September', 10: 'Október', 11: 'November', 12: 'December'}

data = []

path = os.path.dirname(os.path.realpath(__file__))

# Hitboxy okresov
Brt1_x = ["300-380", "300-335", "335-342", "330-370"]
Brt1_y = ["320-360", "300-320", "310-320", "360-366"]

Brt2_x = ["386-570", "470-560", "450-470", "420-450", "410-570", "570-610", "610-650", "420-500", "410-420", "400-410",
          "430-490", "450-470", "500-570", "500-530"]
Brt2_y = ["320-374", "256-320", "280-320", "304-320", "374-420", "396-460", "420-480", "420-560", "420-530", "430-500",
          "560-580", "580-590", "420-470", "470-500"]

Brt3_x = ["295-550", "295-460", "310-440", "350-416", "550-570", "305-520", "374-500", "384-440"]
Brt3_y = ["160-250", "250-270", "270-295", "295-310", "200-240", "150-160", "120-150", "105-120"]

Brt4_x = ["190-284", "284-292", "120-190", "140-190", "170-190", "100-284", "100-180", "180-260", "110-160", "284-294",
          "294-364", "320-380"]
Brt4_y = ["100-350", "270-340", "100-260", "260-284", "284-320", "75-100", "55-75", "65-75", "25-55", "95-170",
          "110-140", "84-110"]

Brt5_x = ["280-399", "270-385", "270-299", "290-390", "310-390", "390-405", "340-390", "280-310", "270-280", "270-300",
          "400-418", "418-440", "440-464", "464-490", "464-510", "510-530"]
Brt5_y = ["390-430", "370-390", "355-370", "430-460", "460-660", "505-710", "660-680", "500-650", "610-650", "650-660",
          "540-710", "586-700", "600-690", "620-635", "635-690", "650-700"]


# Populacie okresov na 100 000 ludi
Brt1_pop_multiplier = 100000 / 39712
Brt2_pop_multiplier = 100000 / 113646
Brt3_pop_multiplier = 100000 / 64545
Brt4_pop_multiplier = 100000 / 95704
Brt5_pop_multiplier = 100000 / 110820


# Citanie csv suborov
class CsvReader:
    def __init__(self, file_name):
        if ".csv" in file_name:
            self.file_name = file_name
        else:
            self.file_name = file_name + ".csv"
        self.nakazeni = []
        self.pripady = 0
        self.nakazy = 0
        self.zeny_nakazy = 0
        self.muzi_nakazy = 0
        self.deti_nakazy = 0
        self.brt1_nakazy = 0
        self.brt2_nakazy = 0
        self.brt3_nakazy = 0
        self.brt4_nakazy = 0
        self.brt5_nakazy = 0

    def read_csv(self):
        self.nakazeni = []
        with open(path + "/files/data/" + self.file_name, encoding="Latin-1") as csv_file:
            csv_reader = csv.DictReader(csv_file, delimiter=";")
            for row in csv_reader:
                poradie = row['Poradie']
                try:
                    pohlavie = row['Pohlavie']
                except KeyError:
                    pohlavie = row['POHLAVIE']
                try:
                    okres = row['Okres']
                except KeyError:
                    okres = row['OKRES']
                try:
                    mc = row['Mestská èas (*v súèasnosti sa nachádza v karanténnom zariadení)']
                except KeyError:
                    try:
                        mc = row['Mestská èas']
                    except KeyError:
                        mc = row['MESTSKÁ ÈAS/OBEC']
                try:
                    poznamka = row['Vylieèení']
                except KeyError:
                    try:
                        poznamka = row['Poznámka']
                    except KeyError:
                        try:
                            poznamka = row['poznámka']
                        except KeyError:
                            poznamka = 0
                self.nakazeni.append({'Poradie': poradie, 'Pohlavie': pohlavie, 'Okres': okres, 'Cast': mc,
                                      'Poznamka': poznamka})
        self.pripady = len(self.nakazeni)
        for i in self.nakazeni:
            if (i['Poznamka'] != 'vylieèený' and i['Poznamka'] != 'vylieèená' and i['Poznamka'] != 'vylieèené'
                    and i["Poznamka"] != "vylieèený/vylieèená/vylieèené"):
                self.nakazy += 1
                if i['Pohlavie'] == "\x9eena":
                    self.zeny_nakazy += 1
                elif i['Pohlavie'] == "mu\x9e":
                    self.muzi_nakazy += 1
                elif i['Pohlavie'] == "die\x9da":
                    self.deti_nakazy += 1

                if i['Okres'] == "Bratislava I" or i['Okres'] == "okres Bratislava I":
                    i['Okres'] = "Bratislava I"
                    self.brt1_nakazy += 1
                elif i['Okres'] == "Bratislava II" or i['Okres'] == "okres Bratislava II":
                    i['Okres'] = "Bratislava II"
                    self.brt2_nakazy += 1
                elif i['Okres'] == "Bratislava III" or i['Okres'] == "okres Bratislava III":
                    i['Okres'] = "Bratislava III"
                    self.brt3_nakazy += 1
                elif i['Okres'] == "Bratislava IV" or i['Okres'] == "okres Bratislava IV":
                    i['Okres'] = "Bratislava IV"
                    self.brt4_nakazy += 1
                elif i['Okres'] == "Bratislava V" or i['Okres'] == "okres Bratislava V":
                    i['Okres'] = "Bratislava V"
                    self.brt5_nakazy += 1


# Funkcia na vyrabanie zoznamov datumov pre posuvac
def date_list(dird):
    os.chdir(dird)

    files_list = []
    dates_list = []

    for f in os.listdir():
        file_name, file_ext = os.path.splitext(f)
        files_list.append(file_name + file_ext)
        year, month, day = [file_name[i:i + 2] for i in range(0, len(file_name), 2)]
        year = int(year) + 2000
        month = mon_list[int(month)]
        day = int(day)
        date = f"{day}. {month} {year}"
        dates_list.append(date)
    return files_list, dates_list


# Funkcia Slideru
def date_func(val):
    global data
    index = int(val)
    den.set("Deň: {}".format(dates[index]))
    den.set("Deň: {}".format(dates[index]))
    global bl1, bl2, bl3, bl4, bl5
    data = CsvReader(files[index])
    data.read_csv()
    # Pripady na 100000 ludi * 255/100 aby prevod na farbu
    p1 = 2.55 * data.brt1_nakazy * Brt1_pop_multiplier
    p2 = 2.55 * data.brt2_nakazy * Brt2_pop_multiplier
    p3 = 2.55 * data.brt3_nakazy * Brt3_pop_multiplier
    p4 = 2.55 * data.brt4_nakazy * Brt4_pop_multiplier
    p5 = 2.55 * data.brt5_nakazy * Brt5_pop_multiplier
    p1, p2, p3, p4, p5 = map(lambda i: (i*0) + 25 if 0 < i < 25 else i, [p1, p2, p3, p4, p5])

    bla1 = Image.open(path + "/files/Brt1.png")
    r, g, b, a = bla1.split()
    g = g.point(lambda i: i - p1)
    b = b.point(lambda i: i - p1)
    bla1 = Image.merge("RGBA", (r, g, b, a))
    bla1 = bla1.resize((114, 120))
    bl1 = ImageTk.PhotoImage(bla1)
    canvas.create_image(340, 324, image=bl1)

    bla2 = Image.open(path + "/files/Brt2.png")
    r, g, b, a = bla2.split()
    g = g.point(lambda i: i - p2)
    b = b.point(lambda i: i - p2)
    bla2 = Image.merge("RGBA", (r, g, b, a))
    bla2 = bla2.resize((300, 364))
    bl2 = ImageTk.PhotoImage(bla2)
    canvas.create_image(506, 424, image=bl2)

    bla3 = Image.open(path + "/files/Brt3.png")
    r, g, b, a = bla3.split()
    g = g.point(lambda i: i - p3)
    b = b.point(lambda i: i - p3)
    bla3 = Image.merge("RGBA", (r, g, b, a))
    bla3 = bla3.resize((310, 238))
    bl3 = ImageTk.PhotoImage(bla3)
    canvas.create_image(430, 213, image=bl3)

    bla4 = Image.open(path + "/files/Brt4.png")
    r, g, b, a = bla4.split()
    g = g.point(lambda i: i - p4)
    b = b.point(lambda i: i - p4)
    bla4 = Image.merge("RGBA", (r, g, b, a))
    bla4 = bla4.resize((344, 355))
    bl4 = ImageTk.PhotoImage(bla4)
    canvas.create_image(260, 182, image=bl4)

    bla5 = Image.open(path + "/files/Brt5.png")
    r, g, b, a = bla5.split()
    g = g.point(lambda i: i - p5)
    b = b.point(lambda i: i - p5)
    bla5 = Image.merge("RGBA", (r, g, b, a))
    bla5 = bla5.resize((313, 387))
    bl5 = ImageTk.PhotoImage(bla5)
    canvas.create_image(398, 533, image=bl5)

    canvas.tag_raise(brt1text)
    canvas.tag_raise(brt2text)
    canvas.tag_raise(brt3text)
    canvas.tag_raise(brt4text)
    canvas.tag_raise(brt5text)


# Funkcia Search baru
def set_date(_):
    def false_input():
        global closed
        if prob == "missing":
            zly_input.config(text="Nie je v databáze...")
        else:
            zly_input.config(text="Nesprávny vstup...")
        zly_input.place(x=1030, y=732)
        for _ in range(7):
            if not closed:
                sleep(0.5)
            else:
                return
        zly_input.place_forget()

    prob = ""
    t1 = threading.Thread(target=false_input)
    ddate = user_input.get()
    user_input.delete(0, tk.END)
    if ddate == "":
        return
    if ddate == "exit":
        root.destroy()
        return
    try:
        day, month, year = ddate.split(".")
    except ValueError:
        print("Nespravny input")
        t1.start()
    else:
        try:
            day, month, year = [int(i) for i in [day, month, year]]
            if year < 100:
                year += 2000
        except ValueError:
            print("Nespravny input")
            t1.start()
        else:
            try:
                month = mon_list[month]
            except KeyError:
                print("Nespravny input")
                t1.start()
            else:
                date = "{}. {} {}".format(day, month, year)
                try:
                    ind = dates.index(date)
                except ValueError:
                    print("Nie je v databaze")
                    prob = "missing"
                    t1.start()
                else:
                    slider.set(ind)


# Funkcia pre zobrazovanie okresov
def on_click(click_event):
    global graphs_open
    if graphs_open:
        return
    x = click_event.x
    y = click_event.y
    for i in range(len(Brt1_x)):
        x1, x2 = Brt1_x[i].split("-")
        y1, y2 = Brt1_y[i].split("-")
        x1, x2, y1, y2 = map(int, [x1, x2, y1, y2])
        if x1 < x < x2:
            if y1 < y < y2:
                buttons("Bratislava I")
                return
    for i in range(len(Brt2_x)):
        x1, x2 = Brt2_x[i].split("-")
        y1, y2 = Brt2_y[i].split("-")
        x1, x2, y1, y2 = map(int, [x1, x2, y1, y2])
        if x1 < x < x2:
            if y1 < y < y2:
                buttons("Bratislava II")
                return
    for i in range(len(Brt3_x)):
        x1, x2 = Brt3_x[i].split("-")
        y1, y2 = Brt3_y[i].split("-")
        x1, x2, y1, y2 = map(int, [x1, x2, y1, y2])
        if x1 < x < x2:
            if y1 < y < y2:
                buttons("Bratislava III")
                return
    for i in range(len(Brt4_x)):
        x1, x2 = Brt4_x[i].split("-")
        y1, y2 = Brt4_y[i].split("-")
        x1, x2, y1, y2 = map(int, [x1, x2, y1, y2])
        if x1 < x < x2:
            if y1 < y < y2:
                buttons("Bratislava IV")
                return
    for i in range(len(Brt5_x)):
        x1, x2 = Brt5_x[i].split("-")
        y1, y2 = Brt5_y[i].split("-")
        x1, x2, y1, y2 = map(int, [x1, x2, y1, y2])
        if x1 < x < x2:
            if y1 < y < y2:
                buttons("Bratislava V")
                return


# Funkcia klikania na okresy
def buttons(okres):
    global graphs_open
    global data
    global Brt1_pop_multiplier
    global Brt2_pop_multiplier
    global Brt3_pop_multiplier
    global Brt4_pop_multiplier
    global Brt5_pop_multiplier

    index = slider.get()
    day = (dates[index] + "\n" + okres)

    def on_closing():
        global graphs_open
        graphs.destroy()
        update.config(state='active')
        slider.config(state='active')
        user_input.config(state='normal')
        graphs_open = False

    # Okno grafov + pozastavenie originalneho okna
    slider.config(state='disabled')
    user_input.config(state='readonly')
    update.config(state='disabled')

    vcerajsok = CsvReader(files[index-1])
    vcerajsok.read_csv()

    graphs = tk.Toplevel()
    graphs.title("Denne data: " + okres)
    graphs.config(background='white')
    graphs.iconbitmap(path + "/files/favicon.ico")
    graphs.geometry('900x700')
    graphs.resizable(0, 0)
    graphs.protocol('WM_DELETE_WINDOW', on_closing)
    graphs_open = True
    casopriestor = tk.Label(graphs, background='white', text=day, font='ARIAL 12 bold')
    casopriestor.place(x=10, y=30)

    exit_but2 = tk.Button(graphs, text="Exit", width=6, command=on_closing)
    exit_but2.pack(anchor='nw')

    # Ziskavanie dat pre grafy
    zeny = 0
    muzi = 0
    deti = 0
    pripady = 0
    nakazy = 0
    deaths = 0
    for person in data.nakazeni:
        if person['Okres'] == okres:
            pripady += 1
            if person['Poznamka'] == '':
                deaths += 1
            if (person['Poznamka'] != 'vylieèený' and person['Poznamka'] != 'vylieèená'
                    and person['Poznamka'] != 'vylieèené' and person["Poznamka"] != "vylieèený/vylieèená/vylieèené"):
                nakazy += 1
                if person['Pohlavie'] == "\x9eena":
                    zeny += 1
                elif person['Pohlavie'] == "mu\x9e":
                    muzi += 1
                elif person['Pohlavie'] == "die\x9da":
                    deti += 1
    vylieceni = pripady - nakazy
    d_change = nakazy
    for person in vcerajsok.nakazeni:
        if person['Okres'] == okres:
            if (person['Poznamka'] != 'vylieèený' and person['Poznamka'] != 'vylieèená'
                    and person['Poznamka'] != 'vylieèené' and person["Poznamka"] != "vylieèený/vylieèená/vylieèené"):
                d_change -= 1

    # Labels
    change = tk.Label(graphs, background='white', text="Zmena v počte nákaz: " + str(d_change), font='ARIAL 12 bold')
    change.place(x=500, y=200)
    deaths = tk.Label(graphs, background='white', text="Počet úmrtí: " + str(deaths), font='ARIAL 12 bold')
    deaths.place(x=500, y=230)

    # Ukazovanie grafov
    f1 = Figure(figsize=(5, 6), dpi=100)
    subplot_1 = f1.add_subplot(111)
    maxy = int(pripady * 1.2)
    if maxy <= 0:
        maxy = 1
        subplot_1.text(0.65, 0.5, "Nebolo testovanie, alebo\nchýbajú pre tento deň dáta",
                       horizontalalignment='center', verticalalignment='center', fontsize=12)
    subplot_1.set_ylim([0, maxy])
    subplot_1.set_title('Počty nakazených', fontsize=18, fontweight='bold', fontfamily='arial')
    subplot_1.bar(0, pripady, width=0.45, color='#eb0e0e', label="_nolegend_")
    subplot_1.bar(0.45, vylieceni, width=0.45, color='#2fd6cf', label="_nolegend_")
    subplot_1.bar(1.35, deti, width=0.45, color='#fed766', bottom=(zeny + muzi), label="Deti")
    subplot_1.bar(1.35, zeny, width=0.45, color='#ff8a99', bottom=muzi, label="Ženy")
    subplot_1.bar(1.35, muzi, width=0.45, color='#57aaeb', label='Muži')
    subplot_1.text(0, pripady / 2, pripady, horizontalalignment='center',  verticalalignment='center', fontsize=12)
    subplot_1.text(0.45, vylieceni / 2, vylieceni, horizontalalignment='center',  verticalalignment='center',
                   fontsize=12)
    subplot_1.text(1.35, muzi / 2, muzi, horizontalalignment='center', verticalalignment='center', fontsize=12)
    subplot_1.text(1.35, muzi + zeny / 2, zeny, horizontalalignment='center', verticalalignment='center', fontsize=12)
    subplot_1.text(1.35, muzi + zeny + deti / 2, deti, horizontalalignment='center', verticalalignment='center',
                   fontsize=12)
    subplot_1.set_xticks([0.45/2, 1.35], minor=False)
    subplot_1.set_xticklabels(["Testy / Z toho vyliečení", "Pohlavie nakazených"], fontdict=None, minor=False)
    subplot_1.legend(loc=1)

    g_canvas = FigureCanvasTkAgg(f1, master=graphs)
    g_canvas.draw()
    g_canvas.get_tk_widget().place(x=0, y=70)


# Funkcia update tlacidla
def datumy(directory=(path + "/files/data")):
    global pocetdni
    global dates
    global files
    files, dates = date_list(directory)
    pocetdni = len(dates) - 1
    slider.config(to=pocetdni)
    slider.set(pocetdni)


# Nastavenie zakladnych premennych potrebnych na funkciu mainloopu
files, dates = date_list(path + "/files/data")
pocetdni = len(dates) - 1
closed = False
graphs_open = False
print(closed)

# Pred nazvom musi byt space inak to da prvy charakter lowercase
root = tk.Tk(className=" Covid Data - Bratislava")
root.configure(background='#b5b5b5')
root.geometry('1200x800')
# Workaround na to ze nefungovala ikonka
root.iconbitmap(path + "/files/favicon.ico")
root.resizable(0, 0)


den = tk.StringVar()


# Exit button
exit_but = tk.Button(root, text="Exit", command=root.destroy, width=6)
exit_but.pack(anchor='nw')

# Update data
update = tk.Button(root, text="Update", font="ARIAL 10 bold", command=datumy, width=10, height=2)
update.pack(anchor='nw', pady=60, padx=30)

# Tlacitka okresov
# Canvas s obrazkami okresov
canvas = tk.Canvas(root, background="#b5b5b5", height=740, width=700, highlightthickness=0)
canvas.place(x=250, y=4)
canvas.bind('<Button-1>', lambda click_event: on_click(click_event))

# Obrazky okresov
# Bratislava 1
bl1 = Image.open(path + "/files/Brt1.png")
bl1 = bl1.resize((114, 120))
bl1 = ImageTk.PhotoImage(bl1)
canvas.create_image(340, 324, image=bl1)
brt1text = canvas.create_text(340, 330, text="Bratislava I", font="ARIAL 14 bold")

# Bratislava 2
bl2 = Image.open(path + "/files/Brt2.png")
bl2 = bl2.resize((300, 364))
bl2 = ImageTk.PhotoImage(bl2)
canvas.create_image(506, 424, image=bl2)
brt2text = canvas.create_text(500, 400, text="Bratislava II", font="ARIAL 14 bold")

# Bratislava 3
bl3 = Image.open(path + "/files/Brt3.png")
bl3 = bl3.resize((310, 238))
bl3 = ImageTk.PhotoImage(bl3)
canvas.create_image(430, 213, image=bl3)
brt3text = canvas.create_text(400, 220, text="Bratislava III", font="ARIAL 14 bold")

# Bratislava 4
bl4 = Image.open(path + "/files/Brt4.png")
bl4 = bl4.resize((344, 355))
bl4 = ImageTk.PhotoImage(bl4)
canvas.create_image(260, 182, image=bl4)
brt4text = canvas.create_text(210, 200, text="Bratislava IV", font="ARIAL 14 bold")

# Bratislava 5
bl5 = Image.open(path + "/files/Brt5.png")
bl5 = bl5.resize((313, 387))
bl5 = ImageTk.PhotoImage(bl5)
canvas.create_image(398, 533, image=bl5)
brt5text = canvas.create_text(350, 550, text="Bratislava V", font="ARIAL 14 bold")

# Aktualny vybrany den
label = tk.Label(root, textvariable=den, bg='#b5b5b5', font='ARIAL 10 bold')
label.place(x=56, y=756)

# Zly input varovanie
zly_input = tk.Label(root, text="", bg='#b5b5b5', highlightthickness=0, bd=0)
zly_input.config(font=('Arial', 14))

# Date slider
slider = tk.Scale(root, from_=0, to=pocetdni, orient='horizontal', length=1100, command=date_func, showvalue=0)
slider.pack(side='bottom')
slider.set(pocetdni)

# Hladaci box
label2 = tk.Label(root, text="Hľadať deň (DD.MM.YYYY):", bg='#b5b5b5', font='ARIAL 10 bold')
label2.place(x=910, y=755)
user_input = tk.Entry(root, width=10)
user_input.place(x=1084, y=756)

# Univerzalne bindy
root.bind('<Return>', set_date)
root.bind('<Escape>', lambda _: root.destroy())
root.bind('<Left>', lambda _: slider.set(slider.get()-1))
root.bind('<Right>', lambda _: slider.set(slider.get()+1))


root.mainloop()
closed = True
